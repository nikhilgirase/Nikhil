

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/*
 * Author : Abhishek Goyal 
 * Purpose : Servlet created to allow the admin to insert the books into the database
 * */
@WebServlet("/Insert")
public class Insert extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public Insert() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//Session object created from the request
		HttpSession hs=request.getSession();
		
		//getting the admin name from the session object
		String name=(String)hs.getAttribute("name");
		
		//printwriter object created 
		PrintWriter pw=response.getWriter();
		
		//dsiplaying the admin name 
		pw.print("<h2> Welcome " +name  +"   </h2>");
		
		pw.print("<h2><marquee> Welcome to Cybage Library System</marquee>  </h2>");
		pw.print("<h3> Welcome Admin </h3>");
		
		pw.print("<form action='InsertDb' method='post'>");
		pw.print("<table align='center' border='1px'>");
		pw.print("<tr>");
		
		//taking all the details from the admin about the book to insert
		pw.print("<td> Enter book title </td>");
		pw.print("<td ><input type='text' name='title'> </td>");
		pw.print("</tr>");
		
		pw.print("<tr>");
		pw.print("<td> Enter book detail </td>");
		pw.print("<td ><input type='text' name='detail'> </td>");
		pw.print("</tr>");
		
		pw.print("<tr>");
		pw.print("<td> Enter book reveiw </td>");
		pw.print("<td ><input type='text' name='review'> </td>");
		pw.print("</tr>");
		
		pw.print("<tr>");
		pw.print("<td ><input type='submit'value='insert'> </td>");
		pw.print("</tr>");
		
		pw.print("</table>");
		pw.print("</form>");
		pw.print("<a href='Adminhome'> back  </td>");
	}
}
