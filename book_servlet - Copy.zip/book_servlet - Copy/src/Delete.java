

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal 
 * Purpose : Servlet created to allow the admin to delete the books based on its title
 * */
@WebServlet("/Delete")
public class Delete extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    public Delete() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
				doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//getting the bookname from the request
		String bookname=request.getParameter("bookname");
		
		//Connect object created to establish a connection to the database 
		Connect c=new Connect();
		Connection con;
		try {
			//establishing connection here
			con=c.getConnection();
			System.out.println(bookname);
			
			//prepared statement created to fire the delte query so based on the title 
			PreparedStatement ps=con.prepareStatement("delete from bookdetails where title=?");
			ps.setString(1,bookname);
			
			//executing the query
			ps.execute();
			System.out.println("deleted");
			
			//redirecting to ths list of books
			response.sendRedirect("List");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	}
}
