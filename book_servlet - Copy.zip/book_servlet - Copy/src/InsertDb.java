

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal
 * Purpose : Servlet created to insert the book into the database
 * */
@WebServlet("/InsertDb")
public class InsertDb extends HttpServlet 

{
	private static final long serialVersionUID = 1L;
       
    public InsertDb() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//connect object created to establish connection with the database
		Connect c=new Connect();
		Connection con;
		try 
		{
			System.out.println("not connected");
			
			//establishing the connection 
			con=c.getConnection();
			System.out.println("connected");
			
			//prepared statement created to fire the insert query into the database
			PreparedStatement ps=con.prepareStatement("insert into bookdetails values (?,?,?)");
			ps.setString(1, request.getParameter("title"));
			ps.setString(2, request.getParameter("detail"));
			ps.setString(3, request.getParameter("review"));
			
			//executing the query
			ps.execute();
			
			//redirecting to the list of books 
			response.sendRedirect("List");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
