package book_servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/*
 * Author : Abhishek Goyal 
 * Purpose : Simple class created to establish the connection to the database
 * */
public class Connect
{
	//a simple method created to get the connection 
	public Connection getConnection() throws ClassNotFoundException, SQLException 
	{
		//loading the driver 
		 Class.forName("com.mysql.jdbc.Driver"); 	 
		 Connection con=null;
		 
		 //creating the connection between the database
		 con= DriverManager.getConnection("jdbc:mysql://localhost/books","root","root");
		 return con;
	}
}
