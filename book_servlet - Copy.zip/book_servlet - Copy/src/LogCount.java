

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
/*
 * Author : Abhishek Goyal
 * Purpose : Servlet created to increment a counter when a users session gets started 
 *			and to decrement when he logs out or invalidates his session
 * */
@WebListener
public class LogCount implements HttpSessionListener {
	static int i=0;
    public LogCount() 
    {
        // TODO Auto-generated constructor stub
    }

	public void sessionCreated(HttpSessionEvent arg0)  
	{ 
    	i++;
    }

	public void sessionDestroyed(HttpSessionEvent arg0)  
	{ 
    	i--;
    }
	public int getCount()
	{
		return i;
	}
}
