package Filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal
 * Purpose : Servlet created to save the time of user logging in into a database
 * */
@SuppressWarnings("unused")
@WebFilter("/MyFilter1")
public class MyFilter1 implements Filter 
{
	public void init(FilterConfig fConfig) throws ServletException 
	{
		System.out.println("started");
	}
	public void destroy() 
	{
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		response.setContentType("text/html");
	
		//printwriter object created
		PrintWriter pw=response.getWriter();
		
		//connect object created to establish a connection to the database
		Connect c=new Connect();
		Connection con;
		try 
		{
			//establishing the connection 	
			con=c.getConnection();
			
			//prepared statement created to fire the select query 
			PreparedStatement ps;
			ps = con.prepareStatement("select * from user where username=? and password=?");			
			ps.setString(1,request.getParameter("uname"));
			ps.setString(2,request.getParameter("upass"));
			//executing the query
			ResultSet rs=ps.executeQuery();
			
			//iterating through the resultset
			while(rs.next())
			{
				System.out.println(rs.getString(1));
				if(rs.getString(1).equals(request.getParameter("uname")))
				{
					//date object created
					Date d=new Date();
					//simple data format object to specify the format of the time 
					SimpleDateFormat sd=new SimpleDateFormat("dd:MM:yy HH:mm:ss");
					String time=sd.format(d);
					
					
				         
				    //formatting the time into a string
						
	
					
					//prepared statement created to fire the update query to save the logging time of the user
					ps=con.prepareStatement("update loguser set count=? ,intime=?, flag=? where username=? ");
					ps.setInt(1,1 );
					ps.setString(2,time);
					ps.setString(3,"active");
					ps.setString(4,request.getParameter("uname"));	
					
					//executing the query
					ps.execute();
					chain.doFilter(request, response);
			
				}
				else
				{
					pw.print("enter valid username or password");
					RequestDispatcher rd=request.getRequestDispatcher("user.html");
					rd.include(request, response);
				}			
		}			
		} catch (Exception e) 
		{				
			e.printStackTrace();
		}
		
		
	}
}
