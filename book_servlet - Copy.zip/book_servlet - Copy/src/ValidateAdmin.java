

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal
 * Purpose : Servlet created to validate the admin  
 * */

@WebServlet("/ValidateAdmin")
public class ValidateAdmin extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    
    public ValidateAdmin() 
    {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
			response.setContentType("text/html");
			PrintWriter pw=response.getWriter();
			Connect c=new Connect();
			Connection con;
			try 
			{
				//establishing the connection
				con=c.getConnection();
				
				//prepared statement created to fire the select query to validate the admin
				PreparedStatement ps;
				ps = con.prepareStatement("select password from admin where username=?");			
				ps.setString(1,request.getParameter("aname"));
				
				//executing the query
				ResultSet rs=ps.executeQuery();
				System.out.println("here");
				
				//iterating the resultset
				while(rs.next())
				{
					System.out.println(rs.getString(1));
				
					if(rs.getString(1).equals(request.getParameter("apass")))
					{
						//if the password matches 
						HttpSession hs=request.getSession(true);
						hs.setAttribute("name",request.getParameter("aname"));
					
						//redirecting to the admin home page 
						response.sendRedirect("Adminhome");					
					}
					else
					{
						//if the credentials are wrong redirecting to the login page
						pw.print("enter valid username or password");
						RequestDispatcher rd=request.getRequestDispatcher("admin.html");
						rd.include(request, response);
					}			
			}			
			} catch (Exception e) 
			{				
				e.printStackTrace();
			}
			
			
	}

}
