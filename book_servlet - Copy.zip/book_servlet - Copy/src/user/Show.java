package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal
 * Purpose : Serl 
 * */
@WebServlet("/Show")
public class Show extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Show() {
        super();
   
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request, response);
	}

	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		//session object created to get the bookname 
		HttpSession hs=request.getSession(false);
		String bookname=request.getParameter("bookname");

		//printwriter object created 
		PrintWriter pw=response.getWriter();
		pw.print("<h2> Welcome " +hs.getAttribute("name1") +"   </h2>");
		
		pw.print("<h2><marquee> Welcome to Cybage Library System</marquee>  </h2>");
		pw.print("<h3> Welcome User </h3>");
		
		//connect object created to establish connection to the database
		Connect c=new Connect();
		
		//getting the booktitle parameter from the request
		String ser=request.getParameter("ser");
		Connection con;
		
	

		
		
		try 
		{
			//establishing the connection
			con=c.getConnection();
			
			//prepared statement created to fire the select query
			PreparedStatement ps=con.prepareStatement("select * from bookdetails where title=?");
			ps.setString(1, ser);		
			
			//executing the query and storing it into a resultset
			ResultSet rs=ps.executeQuery();			
		
			if(!rs.next())
			{				
			
				pw.write("<h4> not found !!! TRY Again!!!! </h4>");
			}			
			else
			{
			
			
			pw.print("<table align='center' border='1px'>");
			pw.print("<tr>");
			pw.print("<td> Title </td>");
			pw.print("<td> Details </td>");
			pw.print("<td> Review </td>");
			pw.print("</tr>");
			pw.print("<tr>");
			pw.print("<td> "+rs.getString(1)+" </td>");
			pw.print("<td> "+rs.getString(2)+" </td>");
			pw.print("<td> "+rs.getString(3)+" </td>");							
			pw.print("</tr>");
				pw.print("</table>");	
			
		}
		}
		catch(Exception e)
		{		
			pw.write("<h4> not found !!! TRY Again!!!! </h4>");
		}
				
		finally{	
		pw.write("<a href=Search> back </a>");}
	}

}
