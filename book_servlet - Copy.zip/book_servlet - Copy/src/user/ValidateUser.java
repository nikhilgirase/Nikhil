package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Timestamp;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;

/*Author : Abhishek Goyal 
 * Purpose : Servlet created to the validate the user
 * */
@SuppressWarnings("unused")
@WebServlet("/ValidateUser")
public class ValidateUser extends HttpServlet 
{
	static int i=0;
	boolean f=false;
	static int j=1;
	private static final long serialVersionUID = 1L;
       
    public ValidateUser() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	
		response.setContentType("text/html");
	
		int a;
		//printwriter object created
		PrintWriter pw=response.getWriter();
		
		//getting the username and password parameters from the requeste
		String uname=request.getParameter("uname");
		String upass=request.getParameter("upass");
		HttpSession session=request.getSession();
		 Cookie[] c1=request.getCookies();
		  ServletContext sc=getServletContext();
		
		  //a=c1.length;
		  if(c1!=null)
		  {
		   if(  c1.length> 1  ) 
			{	
			   for(int b=1;b<c1.length;b++)
			   {
					 if((c1[b].getValue().equals(uname)))
					{
						f=true;
						break;
					}
					else
					{
						f=false;
					}
			  }			
			  if(!f)
			  {
					String name="name"+j;
					Cookie ck1=new Cookie(name,uname);
					ck1.setMaxAge(60*24*24);
					response.addCookie(ck1);					
					i++;
					j++;					
				}			
			  }
		 else if(c1.length==1)
				{
					Cookie ck=new Cookie("name",uname);
					ck.setMaxAge(60*24*24);
					response.addCookie(ck);				
					i++;	
					}
			  }
		 
			sc.setAttribute("UserCount",i );
			session.setAttribute("name1",uname);
		 response.sendRedirect("Userhome");
	}	
}

