package user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal 
 * Purpose : Servlet created to make the user session invalidate 
 * 				and to save the logging out time of the user into the database
 * */
@WebServlet("/LogoutUser")
public class LogoutUser extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public LogoutUser() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//session objkecet created to maintain the session and to get the username
		HttpSession hs=request.getSession(false);
		String str=(String)hs.getAttribute("name1");
		
		//date object created
		Date d=new Date(0);
		
		//simple data format object to specify the format of the date
		SimpleDateFormat sd=new SimpleDateFormat("dd:MM:yy HH:mm:ss");
		String time=sd.format(d);		
		
		//connect object to connect to the database
		Connect c=new Connect();
		Connection con;
		try 
		{	
			//establishing the connection
			con=c.getConnection();	
			
			//prepared statement created to fire the update query
			PreparedStatement ps;
			ps = con.prepareStatement("update loguser set outtime=? ,flag=? where username=?");		
			ps.setString(1, time);
			ps.setString(2, "not");
			ps.setString(3,str);
			
			//executing the query
			ps.execute();
			
			//invalidating the session
			hs.invalidate();
			
			
			System.out.println(time);
			System.out.println(str);
			
			//redirecting to the login page
			response.sendRedirect("Login.html");
		}
		catch(Exception e)
		{
		e.printStackTrace();	
		}
		}

}
