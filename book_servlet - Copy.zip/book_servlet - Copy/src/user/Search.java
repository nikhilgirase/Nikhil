package user;
/*
 * 
 *Author : Abhishek Goyal 
 *Purpose : A view page created using servlet to take the search query from the user
 * */
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/Search")
public class Search extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public Search() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
	
		//sessio objcet created to maintain the session and to get the username 
		HttpSession hs=request.getSession(false);
	
		//printwriter object created
		PrintWriter pw=response.getWriter();
	
		//displayin the username from the session object
		pw.print("<h2> Welcome " +hs.getAttribute("name1") +"   </h2>");
		
		pw.print("<h2><marquee> Welcome to Cybage Library System</marquee>  </h2>");
		pw.print("<h3> Welcome User </h3>");
		pw.print("enter the book name for search ");
		pw.print("<form action='Show' method='post'>");
		
		pw.print("<input type='text' size='100' name='ser'>"); 
	
		pw.print("<input type='submit' value='Search'>");
	
		pw.print("</form>");
		pw.print("<a href='Userhome'> back  </td>");
		
	}

}
