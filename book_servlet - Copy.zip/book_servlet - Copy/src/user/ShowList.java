package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal 
 * Purpose : Servlet created to show the list of books the user has issued
 * */
@WebServlet("/ShowList")
public class ShowList extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public ShowList() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		
		//session object created to maintain the session
		HttpSession hs=request.getSession(false);
	
		//printwriter object created
		PrintWriter pw=response.getWriter();
		
		//displaying the username from the session object
		pw.print("<h2> Welcome " +hs.getAttribute("name1") +"   </h2>");
		
		pw.print("<h2><marquee> Welcome to Cybage Library System</marquee>  </h2>");
		pw.print("<h3> Welcome User </h3>");
		
		//connect object created to establish the connection 
		Connect c=new Connect();
	
		Connection con;
		try 
		{
			//establishing the connection
			con=c.getConnection();
	
			//prepared statemnet created to fire the select query 
			PreparedStatement ps=con.prepareStatement("select * from bookinfo where username=?");
			ps.setString(1, (String)hs.getAttribute("name1"));
			
			//executing the query and storing its result into a resultseta
			ResultSet rs=ps.executeQuery();
			
			pw.print("<table align='center' border='1px'>");
			pw.print("<tr>");
			pw.print("<td> Book Name </td>");
			pw.print("<td> User Review </td>");
			pw.print("<td>Date of Issue</td>");
			pw.print("<td> Date of Return </td>");
			pw.print("<td> Time Period </td>");
			pw.print("<td> Add/Edit Review </td>");
			pw.print("</tr>");
			
			
			//iterating the resultset
			while(rs.next())
			{
				//displaying the result
				pw.print("<tr>");
				pw.print("<td> "+rs.getString(2)+" </td>");
				pw.print("<td> "+rs.getString(3)+" </td>");
				pw.print("<td> "+rs.getString(4)+" </td>");
				pw.print("<td> "+rs.getString(5)+" </td>");
				pw.print("<td> "+rs.getString(6)+" </td>");
				pw.print("<td> <a href=AddReview?bookname="+rs.getString(2)+" > Click  </td>");
				pw.print("<td>");
				pw.print("</tr>");
				
		
			}
			pw.print("<a href='Userhome'> back  </td>");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}

}
