package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal 
 * Purpose : A view page created through servlet to take the reviews to be updated from the user
 * */
@WebServlet("/AddReview")
public class AddReview extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	public AddReview() 
	{
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
	
		//session object created to maintain the session and to get the bookname 
		HttpSession hs=request.getSession(false);
		String bookname=request.getParameter("bookname");
	
		//printwriter object created
		PrintWriter pw=response.getWriter();
		pw.print("<h2> Welcome " +hs.getAttribute("name1") +"   </h2>");
		
		//asking the user to enter his reviews about the books
		pw.print("<h2><marquee> Welcome to Cybage Library System</marquee>  </h2>");
		pw.print("<h3> Welcome User </h3>");
		pw.print("Enter the review");
		pw.print("<form action='AddRevDb' method='post'>");
		pw.print("<input type='text' size='100' name='rev'>"); 
		pw.print("<input type='hidden' name='bookname'  value="+bookname+">");
		pw.print("<input type='submit' value='submit'>");
		pw.print("</form>");

}
	}
