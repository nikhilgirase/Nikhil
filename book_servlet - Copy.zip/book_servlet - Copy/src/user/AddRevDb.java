package user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal 
 * Purpose : Servlet created to add reviews taken from the user to the database 
 * */
@WebServlet("/AddRevDb")
public class AddRevDb extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public AddRevDb() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//getting the bookname and reviews parameters from the request
		String bookname=request.getParameter("bookname");
		String rev=request.getParameter("rev");
		
		//connect object created to establish connection 
		Connect c=new Connect();
		
		Connection con;
		try 
		{
			//establishing the connection
			con=c.getConnection();
	
			//prepared statement created to fire the update query to update reviews 
			PreparedStatement ps=con.prepareStatement("update bookinfo set userview=? where bookname=?");
			ps.setString(1, rev);
			ps.setString(2,bookname);
			
			//executing the query
			ps.execute();
			
			//redirecting to a page which will show the list of books
			response.sendRedirect("ShowList");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			}
		}

}
