package user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/*
 * Author : Abhishek Goyal 
 * Purpose : Servlet created to show the user all the operations he can perform
 * */
@SuppressWarnings("unused")
@WebServlet("/Userhome")
public class Userhome extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
  
    public Userhome() 
    {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		//session object created to maintain the session
		HttpSession hs=request.getSession(false);
	
		//printwriter object created
		PrintWriter pw=response.getWriter();
		
		//displaying the username from the session object
		pw.print("<h2> Welcome " +hs.getAttribute("name1") +"   </h2>");
		
		pw.print("<h2><marquee> Welcome to Cybage Library System</marquee>  </h2>");
		pw.print("<h3> Welcome User </h3>");
	
		pw.write("<h4>Choose following options</h4>");
		pw.print("<table align='center' border='1px'>");
		pw.print("<tr>");
		
		//show list of issued books 
		pw.print("<td> <a href='ShowList'> Show List of Issue Book </a></td>");
		pw.print("</tr>");
		
		//search engine based on the title
		pw.print("<tr>");
		pw.print("<td> <a href='Search'> Search Book </a></td>");
		pw.print("<tr>");
		
		//log out 
		pw.print("<tr>");
		pw.print("<td> <a href='LogoutUser'> Logout </a></td>");
		pw.print("<tr>");

		pw.print("</table>");
		
	}

}
