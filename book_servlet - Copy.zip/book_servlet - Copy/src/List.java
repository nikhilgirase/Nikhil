

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal
 * Purpose : Servlet created to show the admin the list of books
 * */
@WebServlet("/List")
public class List extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public List() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//session object created 
		HttpSession hs=request.getSession();
		response.setContentType("text/html");
		
		//printwriter object created 
		PrintWriter pw=response.getWriter();
		
		//displaying the username from the session object
		pw.print("<h2> Welcome " +hs.getAttribute("name") +"   </h2>");
		
		//creating the connect object
		Connect c=new Connect();
		Connection con;
		try 
		{
			//establishing the connection
			con=c.getConnection();
	
			//prepared statement created to fire the select query 
			PreparedStatement ps=con.prepareStatement("select * from bookdetails");
			
			//executing and result stored into a resultset
			ResultSet rs=ps.executeQuery();
			
			//dsiplaying the books 
			pw.print("<table align='center'  border='1px'>");
			pw.print("<tr>");
			pw.print("<td> Book Name </td>");
			pw.print("<td> Delete </td>");
			pw.print("</tr>");
			
			//iterating through the resultset
			while(rs.next())
			{
				String str=rs.getString(1);
				pw.print("<tr>");
				pw.print("<td> "+str+" </td>");
				pw.print("<td>");
				pw.print("<a href=Delete?bookname="+str+"> Delete  </td>");
				pw.print("</tr>");
			}
			pw.print("<a href='Adminhome'> back  </td>");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
