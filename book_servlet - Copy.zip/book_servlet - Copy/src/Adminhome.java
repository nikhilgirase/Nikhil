

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/*
 * Author : Abhishek Goyal 
 * Purpose : View page created showing all the operations the admin can perform
 * */
@WebServlet("/Adminhome")
public class Adminhome extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public Adminhome() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		//session object created to maintain the session and to get the username 
		HttpSession hs=request.getSession(false);
		
		//printwriter object created to using which html page is created
		PrintWriter pw=response.getWriter();
		
		//displaying the username 
		pw.print("<h2> Welcome " +hs.getAttribute("name") +"   </h2>");

		pw.print("<h2><marquee> Welcome to Cybage Library System</marquee>  </h2>");
		pw.print("<h3> Welcome Admin </h3>");
		pw.print("<h4>   Choose following options </h4>");
		
		//hyperlinks provided to the admin with all operations he can perform
		pw.print("<table align='center' border='1px'>");
		pw.print("<tr>");

		//link for inserting a book
		pw.print("<td> <a href='Insert'> Insert Book </a></td>");
		pw.print("</tr>");
		pw.print("<tr>");
		
		//link for log details 
		pw.print("<td> <a href='Log'> Log Details</a></td>");
		pw.print("</tr>");
		pw.print("<tr>");
		
		//link for list of books
		pw.print("<td> <a href='List'> Book List </a></td>");
		pw.print("</tr>");
		pw.print("<tr>");
		
		//for logging out
		pw.print("<td> <a href='Logout'> Logout </a></td>");
		pw.print("<tr>");
		pw.print("</table>");
	}
}

