

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import book_servlet.Connect;
/*
 * Author : Abhishek Goyal
 * Purpose : Servlet created to  count the number of users and to see how many users are active currently
 * */
@WebServlet("/Log")
public class Log extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Log() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//session object created 
		HttpSession hs=request.getSession(false);	
		
		//servlet context object created 
		ServletContext sc=getServletContext();
		
		//printwriter object created
		PrintWriter pw=response.getWriter();
		
		//displaying the admin name from the session
		pw.print("<h2> Welcome " +hs.getAttribute("name") +"   </h2>");		
		pw.print("<h2><marquee> Welcome to Cybage Library System</marquee>  </h2>");
		pw.print("<h3> Welcome Admin </h3>");
		
		//establishing connection to the database
		Connect c=new Connect();
		Connection con;
		try 
		{
			con=c.getConnection();
		int i=0;
			//prepared statement created to fire the select query to check the user status with active status  
			PreparedStatement ps1=con.prepareStatement("select username from loguser where flag='active'");
			
			//executing the query
			ResultSet rs1=ps1.executeQuery();
			
			//displaying the number of counts to this website
			if(sc.getAttribute("UserCount")==null)
	     	{
				
				pw.print("<h4> No of hit count to this website is 0 </h4>");
	     	}
			else
	     {
	    	
			
			pw.println("<h4> No of hit count to this website is" +sc.getAttribute("UserCount") +" </h4>");
		} 
			
			//displaying users currently active
			pw.print("<h4> Following users are active currently   </h4>");
			while(rs1.next())
			{
				pw.print("<h4> "+rs1.getString(1)+"  </h4>");
			}
				
			//prepared statement created to fire the select query 
			PreparedStatement ps=con.prepareStatement("select * from loguser");
			
			//executing the query
			ResultSet rs=ps.executeQuery();		
			
			
			pw.println("<h3> Last Access Time of Users </h3>");
			pw.print("<table align='center' border='1px'> ");
		
			pw.print("<tr>");
			pw.print("<td> User Name </td>");
			pw.print("<td> In Time </td>");
			pw.print("<td> Out Time </td>");
			pw.print("</tr>");
			
			while(rs.next())
			{
				pw.print("<tr>");
				pw.print("<td> "+rs.getString(1)+" </td>");		
				pw.print("<td> "+rs.getString(3)+" </td>");	
				pw.print("<td> "+rs.getString(4)+" </td>");	
				pw.print("</tr>");	
			}
			pw.print("<a href='Adminhome'> back  </td>");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	
	
	}

}
