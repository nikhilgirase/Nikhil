package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//Implements class having method getConnection() that opens connection and returns Connection instatnce
public class Connection1 

{
	   public Connection getConnection() throws ClassNotFoundException, SQLException {
//		   Registers JDBC Driver	 
		   Class.forName("com.mysql.jdbc.Driver"); 
			 
		   	Connection con=null;
//			creates connection object  
			con= DriverManager.getConnection("jdbc:mysql://localhost/books","root","root"); //Database credentials passed as a parameter
			
			return con;
		}
}
