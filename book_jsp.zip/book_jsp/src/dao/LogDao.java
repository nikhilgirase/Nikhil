package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import connect.Connection1;

//Implements DAO class for Log
public class LogDao 
{
	Connection con;
	
//	Default Constructor
	 public LogDao() 
	 {	
		 System.out.println("in admin ctr");
		 Connection1 c=new Connection1();
		 System.out.println("in connection1");
		 try 
		 {
			con=c.getConnection(); //Opens Connection
		 } 
		 catch (ClassNotFoundException | SQLException e) {
		
			e.printStackTrace();
		}
	}

//	 Shows log, returns result set of log 
	 public ResultSet showLog() throws SQLException
	 {
//		Executes Query
		PreparedStatement ps1=con.prepareStatement("select username from loguser where flag=?");
		ps1.setString(1,"active");
		ResultSet rs1=ps1.executeQuery();
		
		return rs1;
		 
	 }

//	 Retrieves log details, returns result set of log details
	 public ResultSet showLogDetails() throws SQLException
	 {
//	 	Executes Query
		PreparedStatement ps=con.prepareStatement("select * from loguser");
		ResultSet rs=ps.executeQuery();	
		
		return rs;
		 
	 }

}
