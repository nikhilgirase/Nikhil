package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.SimpleDateFormat;
import java.util.Date;

import bean.UserBean;
import connect.Connection1;

//Implements DAO class for User
public class UserDao 
{
	 Connection con;
	 
//	 Default Constructor
	 public UserDao() 
	 {
		 Connection1 c=new Connection1(); 
		 System.out.println("in connection1"); 
		 try 
		 {
			con=c.getConnection(); //Opens Connections
		 } 
		 catch (ClassNotFoundException | SQLException e) {
		
			e.printStackTrace();
		}
	}

//	 Validates User login, and updates user log
	 public boolean validate(UserBean ub) throws SQLException
	 {  
		 boolean b=false;

//		 Validates user
		 PreparedStatement ps=con.prepareStatement("select * from user where username=?");
	 	 ps.setString(1,ub.getUname());
	 	 ResultSet rs=ps.executeQuery();

//	 	 Updates user log
	 	 if(rs.next())
	 	 {
 			b=true;
 			Date d=new Date();
 			SimpleDateFormat sd=new SimpleDateFormat("dd:MM:yy HH:mm:ss");
			         
			String time=sd.format(d);		
			System.out.println(time);

//			Executes Query
			ps=con.prepareStatement("update loguser set count=? ,intime=?, flag=? where username=? ");
			ps.setInt(1,1 );
			ps.setString(2,time);
			ps.setString(3,"active");
			ps.setString(4,ub.getUname());	
			ps.execute();
	 			
	 		}
	 		return b;
	 		
	 	
	 		
	 	}
	 
//	 	updates user log on user logout
	 	public void logout(UserBean ub) throws SQLException
	 	{
	 		Date d=new Date();
			SimpleDateFormat sd=new SimpleDateFormat("dd:MM:yy HH:mm:ss");
			String time=sd.format(d);		

//		 	Updates user log
//			Executes Query
			PreparedStatement ps;
			ps = con.prepareStatement("update loguser set outtime=? ,flag=? where username=?");		
			ps.setString(1, time);
			ps.setString(2, "not");
			ps.setString(3,ub.getUname());
			ps.execute();
	 	}
}
