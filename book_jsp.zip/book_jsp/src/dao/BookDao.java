package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import bean.Book;
import connect.Connection1;

// Implements DAO class for Book
public class BookDao 
{
	 Connection con;
	 
//	 Default Constructors
	 public BookDao() 
	 {	
		 System.out.println("in admin ctr");
		 Connection1 c=new Connection1();
		 System.out.println("in connection1");
		 try 
		 {
			con=c.getConnection(); //Opens Connection
		 } 
		 catch (ClassNotFoundException | SQLException e) {
		
			e.printStackTrace();
		}
	}
	 
//	 Inserts Record
	 public void insert(Book b)
	 {
		 try {
			
//		 		Executes Query
				System.out.println("connected");
				PreparedStatement ps=con.prepareStatement("insert into bookdetails values (?,?,?)");
				ps.setString(1, b.getTitle());
				ps.setString(2, b.getDetail());
				ps.setString(3, b.getReview());
				ps.execute();
			
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		 
	 }
	 
//	 Gets List of Book with their details
	 public ResultSet getList() throws SQLException
	 {
//	 	 Executes Query 
		 PreparedStatement ps=con.prepareStatement("select * from bookdetails");
		 ResultSet rs=ps.executeQuery();
		 
		 return rs; 
	 }

//	 Deletes Book Record
	 public void delete(String title)
	 {
		 try {
//		 		Executes Query
				PreparedStatement ps=con.prepareStatement("delete from bookdetails where title=?");
				ps.setString(1,title);
				ps.execute();
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	 }
	 
//	 Lists Books and details that a particular user has  
	 public ResultSet getBookList(String uname) throws SQLException
	 {
//	 		Executes Query
		 	PreparedStatement ps=con.prepareStatement("select * from bookinfo where username=?");
			ps.setString(1,uname);
			ResultSet rs=ps.executeQuery();
			
			return rs;
	 }
	 
//	 Updates book review provided by user
	 public void updateReview(Book b) throws SQLException
	 {
			 System.out.println(b.getTitle());
			 System.out.println(b.getReview());
		 
//	 		Executes Query
		 	PreparedStatement ps=con.prepareStatement("update bookinfo set userview=? where bookname=?");
			ps.setString(1, b.getReview());
			ps.setString(2,b.getTitle());
			ps.execute();
			
	 }
	 
//	 Implements Book Search Functionality
	 public ResultSet search(Book b) throws SQLException
	 {
//	 		Executes Query		 
			PreparedStatement ps=con.prepareStatement("select * from bookdetails where title=?");
			ps.setString(1,b.getTitle() );		
			ResultSet rs=ps.executeQuery();		
			
			return rs;
			
	 }
}
