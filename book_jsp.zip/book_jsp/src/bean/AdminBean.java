package bean;

//implements bean class for Admin
  public class AdminBean

{
    String aname;
    String apass;
    
//    Default Constructor
     public AdminBean() 
    {
	
	}
     
//     Getter Setters

	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getApass() {
		return apass;
	}

	public void setApass(String apass) {
		this.apass = apass;
	}
     
}
