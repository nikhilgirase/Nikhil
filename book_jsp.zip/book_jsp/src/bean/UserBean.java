package bean;

// Implements Bean class for User
 public class UserBean 

{
	String uname;
	String upass;
	
//	Default Constructor
	public UserBean() 
	{
	
	}
	  
//	Getter and Setter methods	  
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	  
}
